User-agent: *
Disallow: /elybin-install/
Disallow: /elybin-admin/
Disallow: /elybin-file/
Disallow: /elybin-core/
Disallow: /elybin-main/