<?php
// plugin self language library
// module : com.subscribe.php
// lang: Bahasa Indonesia
$lg_subscriptions = "Langganan";
$lg_allsubscriber = "Semua Pelanggan";
$lg_subscribe = "Berlangganan";
$lg_unsubscribe = "Tidak Berlangganan";

$lg_newsubscriber = "Pelanggan baru";
$lg_newsubscribefrom = "Langganan baru dari";
?>