<?php
// com.subscribe
$lg_newsubscriberregistred = "Pelanggan baru terdaftar";
$lg_thankyounowyouwillrecieveupdateautomatically = "Terimakasih, mulai sekarang anda akan menerima pembaharuan secara otomatis";
$lg_ok = "Oke";
$lg_subscribe = "Langganan";
$lg_youremailhere = "E-mail anda disini";
$lg_failedtodotryagain = "Gagal melakukan, coba lagi";
?>