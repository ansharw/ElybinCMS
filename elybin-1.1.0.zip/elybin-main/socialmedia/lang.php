<?php
if(empty($_SESSION['together'])){
	header('location: ../../404.html');
	exit;
}


?>